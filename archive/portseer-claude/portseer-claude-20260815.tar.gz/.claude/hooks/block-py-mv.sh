#!/bin/bash
# Block shell-based renames of .py files. The pyright-langserver daemon
# only learns about new files via LSP didOpen / didChangeWatchedFiles,
# and shell `mv`/`cp`/`git mv` bypass both — leaving stale "import could
# not be resolved" diagnostics for the rest of the session.
#
# Workflow: use the Write tool to create the new file (fires didOpen),
# then Bash `rm` the old, then `git add -A` so git detects the rename.
set -euo pipefail

cmd=$(jq -r '.tool_input.command // ""')

# Verb at a command boundary, followed by a .py path before any pipe.
# [^|]* prevents the .py belonging to a downstream pipe stage (`mv foo
# bar | grep .py`) from triggering a match against the upstream verb.
rename_py_re='(^|[[:space:];&`(])(git[[:space:]]+mv|mv|cp)[[:space:]][^|]*\.py($|[[:space:]"'\''/])'

if echo "$cmd" | grep -qE "$rename_py_re"; then
  jq -n --arg cmd "$cmd" '{
    hookSpecificOutput: {
      hookEventName: "PreToolUse",
      permissionDecision: "deny",
      permissionDecisionReason: ("Blocked: shell mv/cp/git-mv of .py files leaves the Pyright LSP daemon with a stale workspace view, producing false \"import could not be resolved\" diagnostics for the rest of the session.\n\nUse instead:\n  1. Write the new file via the Write tool (fires LSP didOpen so pyright learns the path)\n  2. Bash `rm <old_path>` to remove the original\n  3. `git add -A` afterwards — git detects the rename by content similarity\n\nOriginal command: " + $cmd)
    }
  }'
  exit 0
fi

exit 0
