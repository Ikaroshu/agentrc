#!/bin/bash
# Project-specific extra file suggestions (gitignored dirs)
EXCLUDES=(-g '!__pycache__/' -g '!*.pyc')

# Include gitignored directories
[ -d zscratches ] && rg --files --follow --no-ignore-vcs "${EXCLUDES[@]}" zscratches 2>/dev/null
[ -d docs ] && rg --files --follow --no-ignore-vcs "${EXCLUDES[@]}" docs 2>/dev/null
[ -d auto_research ] && rg --files --follow --no-ignore-vcs "${EXCLUDES[@]}" auto_research 2>/dev/null

# Include their subdirectories
for dir in zscratches docs; do
  [ -d "$dir" ] && find "$dir" -type d -not -name __pycache__ -print | sed 's|$|/|'
done
